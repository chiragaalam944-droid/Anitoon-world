//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BVjCAHWz.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/api/catalog",
			"/api/gplinks",
			"/api/info",
			"/api/search",
			"/api/stream"
		],
		preloads: ["/assets/index-DadOOmkc.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DadOOmkc.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DVSZhonq.js"]
	}
} });
//#endregion
export { tsrStartManifest };
