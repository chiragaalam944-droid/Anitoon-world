import { i as __toESM } from "../_runtime.mjs";
import { R as require_react, _ as useRouter, f as createRouter, g as createRootRoute, h as createFileRoute, l as Scripts, m as lazyRouteComponent, p as Outlet, u as HeadContent, v as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { g as loadStream, h as loadSearch, m as loadInfo, p as loadCatalog } from "./consumet.server-YJMrC-m5.mjs";
import { r as TriangleAlert } from "../_libs/lucide-react.mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-BKX92Oe7.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-dvh flex-col items-center justify-center gap-3 bg-bg px-6 text-center text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-accent",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-2xl",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-muted",
				children: errorMessage(error)
			})
		]
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
var styles_default = "/assets/styles-D6qPRL_P.css";
var APP_NAME = "AniToon World";
var Route$6 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: APP_NAME },
			{
				name: "description",
				content: "AniToon World · Your Ultimate Anime & Cartoon Hub. Family-friendly anime and cartoons to browse, search, and play."
			},
			{
				name: "theme-color",
				content: "#0a0a0c"
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Sora:wght@400;500;600;700&display=swap"
			}
		]
	}),
	component: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		className: "antialiased",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", {
			className: "bg-bg text-fg min-h-dvh",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
			]
		})]
	})
});
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var getHomeCatalog = createServerFn({ method: "GET" }).handler(createSsrRpc("256d3959314d951e32737b16750aeb9cdc96ea1c20b3b31920e140837cbea53f"));
var $$splitComponentImporter = () => import("./routes-BpcchqCz.mjs");
var Route$5 = createFileRoute("/")({
	loader: () => getHomeCatalog(),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
var Route$4 = createFileRoute("/api/catalog")({ server: { handlers: { GET: async ({ request }) => {
	const url = new URL(request.url);
	const kind = url.searchParams.get("kind") || "trending";
	const genre = url.searchParams.get("genre") || void 0;
	const page = Number(url.searchParams.get("page") || "1") || 1;
	try {
		const payload = await loadCatalog({
			kind,
			genre,
			page
		});
		return Response.json(payload);
	} catch (err) {
		const message = err instanceof Error ? err.message : "Catalog failed";
		return Response.json({
			results: [],
			hasNextPage: false,
			error: message
		}, { status: 502 });
	}
} } } });
var AD_KEY = "ad_verified";
var AD_NONCE_KEY = "ad_nonce";
var AD_RESUME_KEY = "ad_resume";
var GPLINKS_API_KEY = "c73a19b90f7153ce05f2c8c2b24fe4b8c51e819f";
var GPLINKS_ST = "https://api.gplinks.com/st?api=";
var GPLINKS_SHORTEN = "https://api.gplinks.com/api?api=";
function isAdVerified() {
	if (typeof window === "undefined") return false;
	try {
		const ts = Number(localStorage.getItem(AD_KEY) || 0);
		return Number.isFinite(ts) && ts > 0 && Date.now() - ts < 1728e5;
	} catch {
		return false;
	}
}
function markAdVerified() {
	localStorage.setItem(AD_KEY, String(Date.now()));
}
function saveAdResume(resume) {
	sessionStorage.setItem(AD_RESUME_KEY, JSON.stringify(resume));
}
function takeAdResume() {
	try {
		const raw = sessionStorage.getItem(AD_RESUME_KEY);
		if (!raw) return null;
		sessionStorage.removeItem(AD_RESUME_KEY);
		return JSON.parse(raw);
	} catch {
		sessionStorage.removeItem(AD_RESUME_KEY);
		return null;
	}
}
function createNonce() {
	const nonce = crypto.randomUUID();
	sessionStorage.setItem(AD_NONCE_KEY, nonce);
	return nonce;
}
function consumeAdReturn() {
	if (typeof window === "undefined") return false;
	const url = new URL(window.location.href);
	const token = url.searchParams.get("ad_token");
	if (token) {
		const nonce = sessionStorage.getItem(AD_NONCE_KEY);
		url.searchParams.delete("ad_token");
		window.history.replaceState({}, "", url.pathname + url.search + url.hash);
		if (nonce && token === nonce) {
			sessionStorage.removeItem(AD_NONCE_KEY);
			markAdVerified();
			return true;
		}
		return isAdVerified();
	}
	return isAdVerified();
}
function currentPageUrl() {
	if (typeof window === "undefined") return "https://example.com/";
	const href = String(window.location.href || "").trim();
	const origin = String(window.location.origin || "").trim();
	const protocol = String(window.location.protocol || "");
	const host = String(window.location.host || "");
	if (/^https?:\/\/\S+/i.test(href)) return href;
	if (/^https?:$/i.test(protocol) && host) return `${protocol}//${host}/`;
	if (/^https?:\/\/\S+/i.test(origin)) return origin.endsWith("/") ? origin : `${origin}/`;
	return "https://example.com/";
}
function getDestinationUrl() {
	const nonce = createNonce();
	let dest = currentPageUrl();
	try {
		const u = new URL(dest);
		if (u.hostname === "localhost" || u.hostname === "[::1]") u.hostname = "127.0.0.1";
		if (u.protocol !== "http:" && u.protocol !== "https:") throw new Error("unsupported protocol");
		u.hash = "";
		u.searchParams.delete("ad_token");
		u.searchParams.set("ad_token", nonce);
		dest = u.toString();
	} catch {
		dest = `http://127.0.0.1/?ad_token=${encodeURIComponent(nonce)}`;
	}
	if (!dest) dest = currentPageUrl();
	return dest;
}
function gplinksUrl(destinationUrl) {
	let dest = typeof destinationUrl === "string" ? destinationUrl.trim() : "";
	if (!dest) dest = getDestinationUrl();
	if (!dest) dest = currentPageUrl();
	return `${GPLINKS_ST}${GPLINKS_API_KEY}&url=${encodeURIComponent(dest)}`;
}
async function startAdSkip() {
	const destinationUrl = getDestinationUrl();
	if (!destinationUrl) throw new Error("Destination URL is missing");
	const data = await (await fetch(`/api/gplinks?url=${encodeURIComponent(destinationUrl)}`, { headers: { accept: "application/json" } })).json();
	if (data.shortenedUrl && /^https?:\/\//i.test(data.shortenedUrl)) return data.shortenedUrl;
	return gplinksUrl(destinationUrl);
}
function normalizeDest(raw) {
	const value = raw.trim();
	if (!value) return null;
	try {
		const u = new URL(value);
		if (u.protocol !== "http:" && u.protocol !== "https:") return null;
		if (u.hostname === "localhost" || u.hostname === "[::1]") u.hostname = "127.0.0.1";
		u.hash = "";
		return u.toString();
	} catch {
		return null;
	}
}
var Route$3 = createFileRoute("/api/gplinks")({ server: { handlers: { GET: async ({ request }) => {
	const dest = normalizeDest(new URL(request.url).searchParams.get("url") || "");
	if (!dest) return Response.json({
		shortenedUrl: "",
		error: "Destination URL is missing"
	}, { status: 400 });
	const api = `${GPLINKS_SHORTEN}${GPLINKS_API_KEY}&url=${encodeURIComponent(dest)}`;
	try {
		const data = await (await fetch(api, {
			headers: { accept: "application/json" },
			signal: AbortSignal.timeout(12e3)
		})).json();
		const shortenedUrl = typeof data.shortenedUrl === "string" ? data.shortenedUrl : "";
		if (!shortenedUrl) return Response.json({
			shortenedUrl: "",
			error: typeof data.message === "string" ? data.message : "URL is invalid"
		});
		return Response.json({
			shortenedUrl,
			destinationUrl: dest
		});
	} catch (err) {
		const message = err instanceof Error ? err.message : "GPLinks request failed";
		return Response.json({
			shortenedUrl: "",
			error: message
		}, { status: 502 });
	}
} } } });
var Route$2 = createFileRoute("/api/info")({ server: { handlers: { GET: async ({ request }) => {
	const url = new URL(request.url);
	const id = url.searchParams.get("id") || "";
	const title = url.searchParams.get("title") || void 0;
	if (!id) return Response.json({ error: "Missing id" }, { status: 400 });
	try {
		const info = await loadInfo(id, title);
		if (!info) return Response.json({ error: "Not found" }, { status: 404 });
		return Response.json(info);
	} catch (err) {
		const message = err instanceof Error ? err.message : "Info failed";
		return Response.json({ error: message }, { status: 502 });
	}
} } } });
var Route$1 = createFileRoute("/api/search")({ server: { handlers: { GET: async ({ request }) => {
	const url = new URL(request.url);
	const q = url.searchParams.get("q") || url.searchParams.get("query") || "";
	const page = Number(url.searchParams.get("page") || "1") || 1;
	try {
		const payload = await loadSearch(q, page, false);
		return Response.json(payload);
	} catch (err) {
		const message = err instanceof Error ? err.message : "Search failed";
		return Response.json({
			results: [],
			hasNextPage: false,
			error: message
		}, { status: 502 });
	}
} } } });
var Route = createFileRoute("/api/stream")({ server: { handlers: { GET: async ({ request }) => {
	const url = new URL(request.url);
	const anilistId = url.searchParams.get("anilistId") || "";
	const episode = Number(url.searchParams.get("episode") || "1") || 1;
	const malRaw = url.searchParams.get("malId");
	const malId = malRaw ? Number(malRaw) : void 0;
	const episodeId = url.searchParams.get("episodeId") || void 0;
	const title = url.searchParams.get("title") || void 0;
	if (!anilistId) return Response.json({ error: "Missing anilistId" }, { status: 400 });
	try {
		const payload = await loadStream({
			anilistId,
			episode,
			malId: Number.isFinite(malId) ? malId : void 0,
			episodeId,
			title
		});
		return Response.json(payload);
	} catch (err) {
		const message = err instanceof Error ? err.message : "Stream failed";
		return Response.json({
			servers: [],
			trailer: null,
			error: message
		}, { status: 502 });
	}
} } } });
var rootRouteChildren = {
	IndexRoute: Route$5.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$6
	}),
	ApiCatalogRoute: Route$4.update({
		id: "/api/catalog",
		path: "/api/catalog",
		getParentRoute: () => Route$6
	}),
	ApiGplinksRoute: Route$3.update({
		id: "/api/gplinks",
		path: "/api/gplinks",
		getParentRoute: () => Route$6
	}),
	ApiInfoRoute: Route$2.update({
		id: "/api/info",
		path: "/api/info",
		getParentRoute: () => Route$6
	}),
	ApiSearchRoute: Route$1.update({
		id: "/api/search",
		path: "/api/search",
		getParentRoute: () => Route$6
	}),
	ApiStreamRoute: Route.update({
		id: "/api/stream",
		path: "/api/stream",
		getParentRoute: () => Route$6
	})
};
var routeTree = Route$6._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { startAdSkip as a, saveAdResume as i, consumeAdReturn as n, takeAdResume as o, isAdVerified as r, Route$5 as s, router_exports as t };
