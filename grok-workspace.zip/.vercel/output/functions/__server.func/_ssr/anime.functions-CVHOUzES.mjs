import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
import { p as loadCatalog } from "./consumet.server-YJMrC-m5.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/anime.functions-CVHOUzES.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var getHomeCatalog_createServerFn_handler = createServerRpc({
	id: "256d3959314d951e32737b16750aeb9cdc96ea1c20b3b31920e140837cbea53f",
	name: "getHomeCatalog",
	filename: "src/lib/anime.functions.ts"
}, (opts) => getHomeCatalog.__executeServer(opts));
var getHomeCatalog = createServerFn({ method: "GET" }).handler(getHomeCatalog_createServerFn_handler, async () => {
	try {
		return (await loadCatalog({
			kind: "trending",
			page: 1
		})).results;
	} catch {
		return [];
	}
});
//#endregion
export { getHomeCatalog_createServerFn_handler };
