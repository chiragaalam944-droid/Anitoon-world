import { i as __toESM } from "../_runtime.mjs";
import { R as require_react, v as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as pushWatchHistory, a as fetchCatalog, c as fetchStream, d as getWatchHistory, f as isInMyList, i as clearWatchHistory, l as getContinueWatching, n as POSTER_FALLBACK, o as fetchInfo, r as buildEmbedServers, s as fetchSearch, t as CATEGORIES, u as getMyList, v as toggleMyList } from "./consumet.server-YJMrC-m5.mjs";
import { a as SkipForward, c as LoaderCircle, d as ChevronRight, f as ChevronLeft, i as Trash2, l as Download, m as BookmarkCheck, n as Tv, o as Search, p as Bookmark, s as Play, t as X, u as Clapperboard } from "../_libs/lucide-react.mjs";
import { a as startAdSkip, i as saveAdResume, n as consumeAdReturn, o as takeAdResume, r as isAdVerified, s as Route$5 } from "./router-BKX92Oe7.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BpcchqCz.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function LangBadges({ badges, compact = false }) {
	if (!badges?.length) return null;
	const shown = compact ? badges.slice(0, 4) : badges;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "flex flex-wrap gap-1",
		children: shown.map((badge) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
			className: cn("rounded-full px-1.5 py-0.5 text-[10px] font-medium tracking-wide uppercase", badge === "Hindi" || badge === "DUB" ? "bg-accent text-accent-fg" : badge === "SUB" ? "bg-fg text-bg" : "bg-bg/75 text-fg backdrop-blur-sm"),
			children: badge
		}, badge))
	});
}
function HeroCarousel({ items, kicker, onPlay, onDetails }) {
	const slides = items.slice(0, 6);
	const [index, setIndex] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		setIndex(0);
	}, [slides[0]?.id]);
	(0, import_react.useEffect)(() => {
		if (slides.length < 2) return;
		const id = window.setInterval(() => {
			setIndex((i) => (i + 1) % slides.length);
		}, 6500);
		return () => window.clearInterval(id);
	}, [slides.length, slides[0]?.id]);
	const hero = slides[index] ?? slides[0];
	if (!hero) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "relative isolate min-h-[420px] overflow-hidden sm:min-h-[560px]",
		children: [
			slides.map((slide, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: slide.cover || slide.image || "/poster-fallback.svg",
				alt: "",
				className: cn("absolute inset-0 h-full w-full object-cover transition-opacity duration-700", i === index ? "opacity-100" : "opacity-0"),
				onError: (e) => {
					e.currentTarget.src = POSTER_FALLBACK;
				}
			}, slide.id)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "hero-veil absolute inset-0" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative mx-auto flex min-h-[420px] max-w-7xl flex-col justify-end px-4 py-10 sm:min-h-[560px] sm:px-6 sm:py-16",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium tracking-[0.18em] text-muted uppercase",
						children: kicker
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-2 max-w-2xl font-display text-4xl leading-[1.05] sm:text-6xl",
						children: hero.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LangBadges, { badges: hero.languages })
					}),
					hero.description ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 max-w-xl line-clamp-3 text-sm leading-relaxed text-muted sm:text-base",
						children: hero.description
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 flex flex-wrap gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => onPlay(hero),
							className: "inline-flex h-12 items-center gap-2 rounded-full bg-accent px-5 text-sm font-medium text-accent-fg transition-transform duration-150 hover:brightness-110 active:scale-[0.98]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "ml-0.5 size-4 fill-current" }), "Watch Now"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => onDetails(hero),
							className: "glass inline-flex h-12 items-center rounded-full px-5 text-sm font-medium text-fg",
							children: "Details"
						})]
					}),
					slides.length > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 flex items-center gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-label": "Previous featured title",
								onClick: () => setIndex((i) => (i - 1 + slides.length) % slides.length),
								className: "glass flex size-11 items-center justify-center rounded-full text-fg",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-4" })
							}),
							slides.map((slide, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-label": `Show ${slide.title}`,
								onClick: () => setIndex(i),
								className: cn("h-1.5 rounded-full transition-all duration-200", i === index ? "w-8 bg-accent" : "w-3 bg-fg/30 hover:bg-fg/50")
							}, slide.id)),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-label": "Next featured title",
								onClick: () => setIndex((i) => (i + 1) % slides.length),
								className: "glass flex size-11 items-center justify-center rounded-full text-fg",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-4" })
							})
						]
					}) : null
				]
			})
		]
	});
}
function AdGate({ resume, onClose }) {
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	async function startSkip() {
		if (busy) return;
		setBusy(true);
		setError(null);
		saveAdResume(resume);
		try {
			const next = await startAdSkip();
			if (!next) throw new Error("Destination URL is missing");
			window.location.assign(next);
		} catch (err) {
			setBusy(false);
			setError(err instanceof Error ? err.message : "Could not start skip ads.");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "absolute inset-0 z-20 flex items-center justify-center bg-bg/80 p-4 backdrop-blur-sm",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "glass w-full max-w-md rounded-xl p-5 sm:p-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mb-4 flex size-12 items-center justify-center rounded-lg bg-accent text-accent-fg",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tv, { className: "size-5" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-display text-xl text-fg",
					children: "Please Skip Ad to Watch or Download"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm leading-relaxed text-muted",
					children: "Complete the skip to unlock 48 hours of ad-free plays and downloads. Refresh and Back will not skip this step."
				}),
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-accent",
					children: error
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5 flex flex-col gap-2 sm:flex-row",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => void startSkip(),
						disabled: busy,
						className: "inline-flex h-12 flex-1 items-center justify-center rounded-full bg-accent px-4 text-sm font-medium text-accent-fg transition-transform duration-150 hover:brightness-110 active:scale-[0.98] disabled:opacity-70",
						children: busy ? "Opening skip…" : "Skip Ads"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onClose,
						className: "inline-flex h-12 items-center justify-center rounded-full bg-surface-2 px-4 text-sm font-medium text-muted hover:text-fg",
						children: "Not now"
					})]
				})
			]
		})
	});
}
function isEndedMessage(data) {
	if (data === "ended" || data === "complete") return true;
	if (typeof data === "string") return /ended|complete|mediaended/i.test(data);
	if (data && typeof data === "object") {
		const rec = data;
		const tokens = [
			rec.event,
			rec.type,
			rec.data,
			rec.action
		].filter((v) => typeof v === "string").join(" ");
		return /ended|complete|mediaended/i.test(tokens);
	}
	return false;
}
function PlayerModal({ anime, startEpisode, onClose, onListChange }) {
	const [info, setInfo] = (0, import_react.useState)(null);
	const [infoError, setInfoError] = (0, import_react.useState)(null);
	const [loadingInfo, setLoadingInfo] = (0, import_react.useState)(true);
	const [episode, setEpisode] = (0, import_react.useState)(null);
	const [pendingAction, setPendingAction] = (0, import_react.useState)(startEpisode ? "play" : null);
	const [pendingEpisode, setPendingEpisode] = (0, import_react.useState)(startEpisode ?? 1);
	const [showAd, setShowAd] = (0, import_react.useState)(false);
	const [servers, setServers] = (0, import_react.useState)([]);
	const [serverId, setServerId] = (0, import_react.useState)(null);
	const [loadingStream, setLoadingStream] = (0, import_react.useState)(false);
	const [streamError, setStreamError] = (0, import_react.useState)(null);
	const [saved, setSaved] = (0, import_react.useState)(() => isInMyList(anime.id));
	const [autoNext, setAutoNext] = (0, import_react.useState)(true);
	const [nextCountdown, setNextCountdown] = (0, import_react.useState)(null);
	const countdownRef = (0, import_react.useRef)(null);
	const autoNextRef = (0, import_react.useRef)(autoNext);
	const episodeRef = (0, import_react.useRef)(episode);
	const maxEpRef = (0, import_react.useRef)(1);
	const episodes = info?.episodes ?? [{
		id: "1",
		number: 1,
		title: "Episode 1"
	}];
	const maxEp = episodes[episodes.length - 1]?.number ?? 1;
	autoNextRef.current = autoNext;
	episodeRef.current = episode;
	maxEpRef.current = maxEp;
	const requestPlay = (0, import_react.useCallback)((ep) => {
		const immediate = buildEmbedServers(anime.id, anime.malId, ep, anime.title);
		setServers(immediate);
		setServerId(immediate[0]?.id ?? null);
		setLoadingStream(false);
		setStreamError(immediate.length ? null : "No playback mirrors are available for this episode.");
		if (isAdVerified()) {
			setShowAd(false);
			setEpisode(ep);
			return;
		}
		setPendingAction("play");
		setPendingEpisode(ep);
		setShowAd(true);
	}, [anime.id, anime.malId]);
	const goNext = (0, import_react.useCallback)(() => {
		const current = episodeRef.current;
		if (!current) return;
		const idx = episodes.findIndex((e) => e.number === current);
		const next = episodes[idx + 1] ?? episodes.find((e) => e.number === current + 1);
		if (next) requestPlay(next.number);
	}, [episodes, requestPlay]);
	const goPrev = (0, import_react.useCallback)(() => {
		const current = episodeRef.current;
		if (!current) return;
		const idx = episodes.findIndex((e) => e.number === current);
		const prev = episodes[idx - 1] ?? episodes.find((e) => e.number === current - 1);
		if (prev) requestPlay(prev.number);
	}, [episodes, requestPlay]);
	(0, import_react.useEffect)(() => {
		const prev = document.body.style.overflow;
		document.body.style.overflow = "hidden";
		const onKey = (e) => {
			if (e.key === "Escape") onClose();
		};
		window.addEventListener("keydown", onKey);
		return () => {
			document.body.style.overflow = prev;
			window.removeEventListener("keydown", onKey);
		};
	}, [onClose]);
	(0, import_react.useEffect)(() => {
		consumeAdReturn();
		if (startEpisode && isAdVerified()) requestPlay(startEpisode);
		else if (startEpisode) {
			setShowAd(true);
			setPendingAction("play");
			setPendingEpisode(startEpisode);
		}
	}, [startEpisode, requestPlay]);
	(0, import_react.useEffect)(() => {
		let cancelled = false;
		setLoadingInfo(true);
		setInfoError(null);
		fetchInfo(anime.id, anime.title).then((data) => {
			if (cancelled) return;
			setInfo(data);
		}).catch((err) => {
			if (cancelled) return;
			setInfoError(err instanceof Error ? err.message : "Could not load details");
		}).finally(() => {
			if (!cancelled) setLoadingInfo(false);
		});
		return () => {
			cancelled = true;
		};
	}, [anime.id, anime.title]);
	(0, import_react.useEffect)(() => {
		if (!episode) return;
		const immediate = buildEmbedServers(info?.id ?? anime.id, info?.malId ?? anime.malId, episode, info?.title ?? anime.title);
		setServers(immediate);
		setServerId((current) => current ?? immediate[0]?.id ?? null);
		setLoadingStream(false);
		setStreamError(immediate.length ? null : "No playback mirrors are available for this episode.");
		pushWatchHistory({
			id: info?.id ?? anime.id,
			malId: info?.malId ?? anime.malId,
			title: info?.title ?? anime.title,
			image: info?.image ?? anime.image,
			episode,
			updatedAt: Date.now()
		});
		onListChange();
		let cancelled = false;
		const epMeta = info?.episodes.find((e) => e.number === episode);
		fetchStream({
			anilistId: info?.id ?? anime.id,
			malId: info?.malId ?? anime.malId,
			episode,
			episodeId: epMeta?.id,
			title: info?.title ?? anime.title
		}).then((payload) => {
			if (cancelled || !payload.servers.length) return;
			setServers((prev) => {
				const seen = new Set(prev.map((s) => s.url));
				const extra = payload.servers.filter((s) => !seen.has(s.url));
				return extra.length ? [...prev, ...extra] : prev;
			});
		}).catch(() => {});
		return () => {
			cancelled = true;
		};
	}, [
		episode,
		info,
		anime.id,
		anime.malId,
		anime.title,
		anime.image,
		onListChange
	]);
	(0, import_react.useEffect)(() => {
		function onMsg(e) {
			if (!isEndedMessage(e.data) || !autoNextRef.current) return;
			const current = episodeRef.current;
			if (!current || current >= maxEpRef.current) return;
			setNextCountdown((n) => n ?? 8);
		}
		window.addEventListener("message", onMsg);
		return () => window.removeEventListener("message", onMsg);
	}, []);
	(0, import_react.useEffect)(() => {
		if (nextCountdown == null) return;
		if (nextCountdown <= 0) {
			setNextCountdown(null);
			goNext();
			return;
		}
		countdownRef.current = window.setTimeout(() => {
			setNextCountdown((n) => n == null ? n : n - 1);
		}, 1e3);
		return () => {
			if (countdownRef.current) window.clearTimeout(countdownRef.current);
		};
	}, [nextCountdown, goNext]);
	const activeServer = (0, import_react.useMemo)(() => servers.find((s) => s.id === serverId) ?? servers[0], [servers, serverId]);
	const display = info ?? anime;
	const description = display.description || "No synopsis is available yet.";
	function onToggleList() {
		toggleMyList({
			id: display.id,
			malId: display.malId,
			title: display.title,
			image: display.image
		});
		setSaved(isInMyList(display.id));
		onListChange();
	}
	function runDownload() {
		const url = activeServer?.download || activeServer?.url || (display.malId ? `https://vidsrc.pm/embed/anime/${display.malId}/${pendingEpisode ?? episode ?? 1}` : null);
		if (url) window.open(url, "_blank", "noopener,noreferrer");
	}
	function onDownload() {
		if (isAdVerified()) {
			if (!episode) requestPlay(pendingEpisode ?? 1);
			runDownload();
			return;
		}
		setPendingAction("download");
		setShowAd(true);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 flex items-end justify-center bg-bg/80 p-0 sm:items-center sm:p-6",
		role: "presentation",
		onClick: onClose,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			role: "dialog",
			"aria-modal": "true",
			"aria-labelledby": "atw-player-title",
			className: "relative flex max-h-dvh w-full max-w-5xl flex-col overflow-hidden rounded-t-xl bg-surface shadow-border sm:max-h-[min(92dvh,920px)] sm:rounded-xl",
			onClick: (e) => e.stopPropagation(),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative aspect-video w-full bg-bg",
					children: [
						episode && activeServer && !loadingStream ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("iframe", {
							title: `${display.title} player`,
							src: activeServer.url,
							className: "h-full w-full border-0",
							allow: "accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; fullscreen",
							allowFullScreen: true,
							referrerPolicy: "no-referrer",
							onError: () => {
								const idx = servers.findIndex((s) => s.id === activeServer.id);
								const fallback = servers[idx + 1];
								if (fallback) setServerId(fallback.id);
							}
						}, `${activeServer.url}-${episode}`) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "absolute inset-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: display.cover || display.image || "/poster-fallback.svg",
								alt: "",
								className: "h-full w-full object-cover opacity-50",
								onError: (e) => {
									e.currentTarget.src = POSTER_FALLBACK;
								}
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "absolute inset-0 flex flex-col items-center justify-center gap-3 bg-bg/40",
								children: loadingStream || loadingInfo && startEpisode ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "atw-spinner",
									"aria-hidden": true
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-muted",
									children: "Loading player…"
								})] }) : streamError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "max-w-md px-6 text-center text-sm text-muted",
									children: streamError
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									className: "flex h-12 items-center gap-2 rounded-full bg-accent px-5 text-sm font-medium text-accent-fg transition-transform duration-150 hover:brightness-110 active:scale-[0.98]",
									onClick: () => requestPlay(startEpisode || 1),
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "ml-0.5 size-4 fill-current" }),
										"Play episode ",
										startEpisode || 1
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted",
									children: "Choose an episode below to start"
								})] })
							})]
						}),
						nextCountdown != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "absolute inset-x-0 bottom-0 flex items-center justify-between gap-3 bg-bg/80 px-4 py-3 backdrop-blur-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-sm text-fg",
								children: [
									"Next episode in ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "tabular-nums",
										children: nextCountdown
									}),
									"s"
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "h-10 rounded-full bg-surface-2 px-3 text-xs font-medium text-muted",
									onClick: () => setNextCountdown(null),
									children: "Cancel"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									className: "inline-flex h-10 items-center gap-1 rounded-full bg-accent px-3 text-xs font-medium text-accent-fg",
									onClick: () => {
										setNextCountdown(null);
										goNext();
									},
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SkipForward, { className: "size-3.5" }), "Play now"]
								})]
							})]
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-label": "Close player",
							onClick: onClose,
							className: "absolute top-3 right-3 z-10 flex size-10 items-center justify-center rounded-full bg-bg/80 text-fg backdrop-blur-sm transition-opacity duration-150 hover:opacity-90",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
						}),
						showAd ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdGate, {
							resume: {
								id: anime.id,
								malId: anime.malId,
								title: anime.title,
								image: anime.image,
								episode: pendingEpisode ?? startEpisode ?? 1,
								action: pendingAction ?? "play"
							},
							onClose: () => setShowAd(false)
						}) : null
					]
				}),
				servers.length > 0 && episode ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-2 border-b border-border px-4 py-3 sm:px-6",
					children: [servers.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setServerId(s.id),
						className: cn("h-9 rounded-full px-3 text-xs font-medium transition-colors duration-150", s.id === activeServer?.id ? "bg-fg text-bg" : "bg-surface-2 text-muted hover:text-fg"),
						children: s.name
					}, s.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "w-full text-[11px] text-subtle sm:ml-auto sm:w-auto",
						children: "If playback does not start, try another server."
					})]
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-h-0 flex-1 overflow-y-auto p-4 sm:p-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-start justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										id: "atw-player-title",
										className: "font-display text-2xl leading-tight text-fg sm:text-3xl",
										children: display.title
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-1 flex flex-wrap gap-x-3 gap-y-1 text-xs text-muted",
										children: [
											display.releaseDate ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: display.releaseDate }) : null,
											display.type ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: display.type }) : null,
											display.status ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: display.status.replaceAll("_", " ") }) : null,
											episode ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "tabular-nums",
												children: ["Episode ", episode]
											}) : null
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mt-3",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LangBadges, { badges: display.languages })
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: onToggleList,
									className: cn("inline-flex h-11 items-center gap-2 rounded-full px-4 text-sm font-medium transition-colors duration-150", saved ? "bg-surface-2 text-fg shadow-border" : "bg-fg text-bg hover:opacity-90"),
									children: [saved ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookmarkCheck, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, { className: "size-4" }), saved ? "In watchlist" : "Watchlist"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: onDownload,
									className: "inline-flex h-11 items-center gap-2 rounded-full bg-surface-2 px-4 text-sm font-medium text-fg shadow-border hover:shadow-border-hover",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4" }), "Download"]
								})]
							})]
						}),
						display.genres?.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-3 flex flex-wrap gap-1.5",
							children: display.genres.slice(0, 8).map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
								className: "rounded-full bg-surface-2 px-2.5 py-1 text-[11px] text-muted",
								children: g
							}, g))
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 max-w-3xl text-sm leading-relaxed text-muted",
							children: description
						}),
						infoError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-sm text-accent",
							children: infoError
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-6 flex flex-wrap items-center justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: goPrev,
									disabled: !episode || episode <= (episodes[0]?.number ?? 1),
									className: "inline-flex h-11 items-center gap-1 rounded-full bg-surface-2 px-3 text-sm font-medium text-fg disabled:opacity-40",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-4" }), "Prev"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: goNext,
									disabled: !episode || episode >= maxEp,
									className: "inline-flex h-11 items-center gap-1 rounded-full bg-surface-2 px-3 text-sm font-medium text-fg disabled:opacity-40",
									children: ["Next", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-4" })]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "inline-flex h-11 items-center gap-2 text-sm text-muted",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "checkbox",
									checked: autoNext,
									onChange: (e) => setAutoNext(e.target.checked),
									className: "size-4 accent-accent"
								}), "Auto-next episode"]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-6",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mb-3 text-xs font-medium tracking-wide text-subtle uppercase",
								children: ["Episodes", info?.episodes?.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "ml-2 tabular-nums text-muted",
									children: info.episodes.length
								}) : null]
							}), loadingInfo ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2 text-sm text-muted",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin" }), "Fetching episode list…"]
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid max-h-56 grid-cols-5 gap-2 overflow-y-auto sm:grid-cols-8 md:grid-cols-10",
								children: episodes.map((ep) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => requestPlay(ep.number),
									className: cn("h-10 rounded-md text-sm tabular-nums transition-colors duration-150", episode === ep.number ? "bg-accent text-accent-fg" : "bg-surface-2 text-fg hover:bg-border"),
									title: ep.title,
									children: ep.number
								}, ep.id))
							})]
						})
					]
				})
			]
		})
	});
}
function PosterCard({ anime, onOpen, onListChange, index = 0 }) {
	const [saved, setSaved] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		setSaved(isInMyList(anime.id));
	}, [anime.id]);
	function onBookmark(e) {
		e.stopPropagation();
		e.preventDefault();
		toggleMyList({
			id: anime.id,
			malId: anime.malId,
			title: anime.title,
			image: anime.image
		});
		setSaved(isInMyList(anime.id));
		onListChange?.();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("group atw-rise relative aspect-poster w-full overflow-hidden rounded-md bg-surface text-left", "shadow-border transition-[transform,box-shadow] duration-200 ease-smooth-out", "hover:z-10 hover:scale-[1.04] hover:shadow-neon", "focus-within:shadow-neon"),
		style: { animationDelay: `${Math.min(index, 12) * 40}ms` },
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: () => onOpen(anime),
			className: "absolute inset-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-fg",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: anime.image || "/poster-fallback.svg",
					alt: "",
					loading: "lazy",
					className: "h-full w-full object-cover transition-transform duration-200 ease-smooth-out group-hover:scale-[1.04]",
					onError: (e) => {
						e.currentTarget.src = POSTER_FALLBACK;
					}
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "pointer-events-none absolute inset-0 poster-veil opacity-90" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "absolute inset-0 flex items-center justify-center opacity-0 transition-opacity duration-250 group-hover:opacity-100",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "flex size-11 items-center justify-center rounded-full bg-accent text-accent-fg shadow-lg",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "ml-0.5 size-5 fill-current" })
					})
				}),
				anime.rating ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "absolute top-2 right-2 rounded-full bg-bg/80 px-2 py-0.5 text-[11px] font-medium tabular-nums text-fg backdrop-blur-sm",
					children: anime.rating > 10 ? (anime.rating / 10).toFixed(1) : anime.rating
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "absolute inset-x-0 bottom-0 p-2.5 text-left",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LangBadges, {
							badges: anime.languages,
							compact: true
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-1.5 line-clamp-2 block font-medium text-sm leading-snug text-fg",
							children: anime.title
						}),
						anime.releaseDate ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-0.5 block text-[11px] text-muted",
							children: anime.releaseDate
						}) : null
					]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			"aria-label": saved ? "Remove from watchlist" : "Add to watchlist",
			onClick: onBookmark,
			className: "absolute top-2 left-2 z-10 flex size-11 items-center justify-center rounded-full bg-bg/80 text-fg backdrop-blur-sm hover:bg-bg",
			children: saved ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookmarkCheck, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, { className: "size-4" })
		})]
	});
}
function entryToCard(entry) {
	return {
		id: entry.id,
		malId: entry.malId,
		title: entry.title,
		image: entry.image
	};
}
function Shelf({ title, action, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "pt-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-4 flex items-center justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-2xl",
				children: title
			}), action]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex gap-3 overflow-x-auto pb-2",
			children
		})]
	});
}
function Thumb({ entry, onOpen, caption }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick: () => onOpen(entryToCard(entry), entry.episode),
		className: "w-[140px] shrink-0 text-left sm:w-[160px]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "relative block aspect-poster overflow-hidden rounded-md bg-surface shadow-border",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: entry.image || "/poster-fallback.svg",
				alt: "",
				className: "h-full w-full object-cover",
				onError: (e) => {
					e.currentTarget.src = POSTER_FALLBACK;
				}
			}), caption ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "absolute inset-x-0 bottom-0 bg-bg/80 px-2 py-1.5 text-[11px] text-muted",
				children: caption
			}) : null]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mt-2 line-clamp-2 text-sm font-medium",
			children: entry.title
		})]
	});
}
function AniToonApp({ initialItems = [] }) {
	const [category, setCategory] = (0, import_react.useState)(CATEGORIES[0]);
	const [items, setItems] = (0, import_react.useState)(initialItems);
	const [loading, setLoading] = (0, import_react.useState)(!initialItems.length);
	const [loadingMore, setLoadingMore] = (0, import_react.useState)(false);
	const [hasNextPage, setHasNextPage] = (0, import_react.useState)(true);
	const [page, setPage] = (0, import_react.useState)(1);
	const [error, setError] = (0, import_react.useState)(null);
	const [query, setQuery] = (0, import_react.useState)("");
	const [searching, setSearching] = (0, import_react.useState)(false);
	const [active, setActive] = (0, import_react.useState)(null);
	const [startEpisode, setStartEpisode] = (0, import_react.useState)();
	const [continueWatching, setContinueWatching] = (0, import_react.useState)([]);
	const [history, setHistory] = (0, import_react.useState)([]);
	const [myList, setMyList] = (0, import_react.useState)([]);
	const [showList, setShowList] = (0, import_react.useState)(false);
	const searchRef = (0, import_react.useRef)(null);
	const debounceRef = (0, import_react.useRef)(null);
	const skipFirst = (0, import_react.useRef)(initialItems.length > 0);
	const refreshLocal = (0, import_react.useCallback)(() => {
		setContinueWatching(getContinueWatching());
		setHistory(getWatchHistory());
		setMyList(getMyList());
	}, []);
	(0, import_react.useEffect)(() => {
		const verified = consumeAdReturn();
		refreshLocal();
		if (!verified) return;
		const resume = takeAdResume();
		if (!resume) return;
		setActive({
			id: resume.id,
			malId: resume.malId,
			title: resume.title,
			image: resume.image
		});
		setStartEpisode(resume.episode);
	}, [refreshLocal]);
	(0, import_react.useEffect)(() => {
		const onKey = (e) => {
			if (e.key === "/" && document.activeElement?.tagName !== "INPUT") {
				e.preventDefault();
				searchRef.current?.focus();
			}
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, []);
	const loadCategory = (0, import_react.useCallback)(async (cat, nextPage = 1) => {
		setLoading(true);
		setError(null);
		try {
			const data = await fetchCatalog(cat.kind, cat.genre, nextPage);
			setItems(data.results);
			setHasNextPage(data.hasNextPage && data.results.length > 0);
			setPage(nextPage);
			if (!data.results.length) setError("Nothing in this shelf yet. Try another filter.");
		} catch (err) {
			setItems([]);
			setError(err instanceof Error ? err.message : "Could not load the catalog.");
			setHasNextPage(false);
		} finally {
			setLoading(false);
			setLoadingMore(false);
		}
	}, []);
	(0, import_react.useEffect)(() => {
		if (query.trim().length >= 2) return;
		if (skipFirst.current && category.id === "trending") {
			skipFirst.current = false;
			setHasNextPage(true);
			setPage(1);
			return;
		}
		loadCategory(category, 1);
	}, [
		category,
		loadCategory,
		query
	]);
	const runSearch = (0, import_react.useCallback)(async (q, nextPage = 1) => {
		setLoading(true);
		setError(null);
		setShowList(false);
		try {
			const data = await fetchSearch(q, nextPage);
			setItems(data.results);
			setHasNextPage(data.hasNextPage && data.results.length > 0);
			setPage(nextPage);
			if (!data.results.length) setError(`No titles match “${q}”.`);
		} catch (err) {
			setItems([]);
			setError(err instanceof Error ? err.message : "Search failed.");
			setHasNextPage(false);
		} finally {
			setLoading(false);
			setSearching(false);
			setLoadingMore(false);
		}
	}, []);
	function onSearchChange(value) {
		setQuery(value);
		if (debounceRef.current) window.clearTimeout(debounceRef.current);
		if (value.trim().length < 2) {
			setSearching(false);
			return;
		}
		setSearching(true);
		debounceRef.current = window.setTimeout(() => {
			runSearch(value.trim(), 1);
		}, 400);
	}
	const goPage = (0, import_react.useCallback)((next) => {
		if (next < 1 || loading || loadingMore) return;
		const q = query.trim();
		window.scrollTo({
			top: 0,
			behavior: "smooth"
		});
		if (q.length >= 2) {
			runSearch(q, next);
			return;
		}
		loadCategory(category, next);
	}, [
		loading,
		loadingMore,
		query,
		category,
		loadCategory,
		runSearch
	]);
	const heroSlides = (0, import_react.useMemo)(() => items.slice(0, 6), [items]);
	const heading = query.trim().length >= 2 ? `Results for “${query.trim()}”` : showList ? "Watchlist" : category.label;
	const gridItems = showList ? myList.map(entryToCard) : items;
	const browsing = query.trim().length < 2 && !showList;
	function openAnime(anime, episode) {
		setActive(anime);
		setStartEpisode(episode);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "glass sticky top-0 z-40 border-b border-border/60",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-7xl flex-col gap-3 px-4 py-3 sm:h-18 sm:flex-row sm:items-center sm:gap-3 sm:px-6 sm:py-0",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: "/",
								className: "flex shrink-0 items-center gap-2",
								"aria-label": "AniToon World home",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "flex size-8 items-center justify-center rounded-sm bg-accent text-accent-fg",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "ml-0.5 size-3.5 fill-current" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "leading-none",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block font-display text-lg tracking-tight sm:text-xl",
										children: "AniToon World"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "hidden text-[10px] tracking-wide text-muted uppercase sm:block",
										children: "Anime & cartoon hub"
									})]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "ml-auto sm:hidden",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => {
										setShowList((v) => !v);
										setQuery("");
									},
									className: cn("inline-flex size-11 items-center justify-center rounded-full text-sm font-medium", showList ? "bg-fg text-bg" : "text-muted hover:text-fg"),
									"aria-label": "Watchlist",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, { className: "size-4" })
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "relative min-w-0 flex-1 sm:mx-auto sm:max-w-xl",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "sr-only",
									children: "Search anime and cartoons"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-subtle" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									ref: searchRef,
									value: query,
									onChange: (e) => onSearchChange(e.target.value),
									placeholder: "Search Solo Leveling, Naruto, Jujutsu Kaisen…",
									className: "h-11 w-full rounded-full bg-surface-2 pr-10 pl-10 text-sm text-fg shadow-border placeholder:text-subtle focus:shadow-border-hover focus:outline-none"
								}),
								query ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									"aria-label": "Clear search",
									className: "absolute top-1/2 right-2 flex size-8 -translate-y-1/2 items-center justify-center rounded-full text-muted hover:text-fg",
									onClick: () => {
										setQuery("");
										setSearching(false);
									},
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
								}) : null
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => {
								setShowList((v) => !v);
								setQuery("");
							},
							className: cn("hidden h-11 shrink-0 items-center gap-2 rounded-full px-3 text-sm font-medium sm:inline-flex", showList ? "bg-fg text-bg" : "text-muted hover:text-fg"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, { className: "size-4" }), "Watchlist"]
						})
					]
				})
			}),
			heroSlides.length > 0 && browsing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeroCarousel, {
				items: heroSlides,
				kicker: `AniToon World · ${category.id === "cartoons" ? "Kids & cartoons" : category.id === "hindi" ? "Hindi dubbed" : "Trending now"}`,
				onPlay: (anime) => openAnime(anime, 1),
				onDetails: (anime) => openAnime(anime)
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "mx-auto max-w-7xl px-4 pb-20 sm:px-6",
				children: [
					continueWatching.length > 0 && browsing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shelf, {
						title: "Continue watching",
						children: continueWatching.map((entry) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Thumb, {
							entry,
							onOpen: openAnime,
							caption: `Ep ${entry.episode}`
						}, `cw-${entry.id}`))
					}) : null,
					history.length > 0 && browsing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shelf, {
						title: "Watch history",
						action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => {
								clearWatchHistory();
								refreshLocal();
							},
							className: "inline-flex h-11 items-center gap-2 rounded-full bg-surface-2 px-3 text-sm font-medium text-muted hover:text-fg",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" }), "Clear history"]
						}),
						children: history.map((entry) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Thumb, {
							entry,
							onOpen: openAnime,
							caption: `Ep ${entry.episode}`
						}, `h-${entry.id}-${entry.episode}-${entry.updatedAt}`))
					}) : null,
					myList.length > 0 && browsing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shelf, {
						title: "Watchlist",
						children: myList.map((entry) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Thumb, {
							entry,
							onOpen: openAnime
						}, `wl-${entry.id}`))
					}) : null,
					browsing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "-mx-4 mt-8 flex gap-2 overflow-x-auto px-4 pb-1 sm:mx-0 sm:flex-wrap sm:px-0",
						"aria-label": "Categories",
						children: CATEGORIES.map((cat) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setCategory(cat),
							className: cn("h-10 shrink-0 rounded-full px-4 text-sm font-medium transition-colors duration-150", category.id === cat.id ? "bg-fg text-bg" : "bg-surface-2 text-muted hover:text-fg"),
							children: cat.label
						}, cat.id))
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "mt-8",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mb-5 flex items-end justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "font-display text-2xl sm:text-3xl",
									children: heading
								}), searching || loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "atw-spinner",
									"aria-label": "Loading"
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clapperboard, {
									className: "size-5 text-subtle",
									"aria-hidden": true
								})]
							}),
							loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid grid-cols-2 gap-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6",
								children: Array.from({ length: 12 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "atw-skeleton aspect-poster rounded-md" }, i))
							}) : error && !gridItems.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "rounded-xl bg-surface px-5 py-12 text-center shadow-border",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-muted",
									children: error
								})
							}) : showList && !gridItems.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "rounded-xl bg-surface px-5 py-12 text-center shadow-border",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-muted",
									children: "Your watchlist is empty. Bookmark a title to save it for later."
								})
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid grid-cols-2 gap-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6",
								children: gridItems.map((anime, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PosterCard, {
									anime,
									onOpen: openAnime,
									onListChange: refreshLocal,
									index: i
								}, `${anime.id}-${i}`))
							}),
							!showList && !loading && gridItems.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-8 flex flex-wrap items-center justify-center gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										disabled: page <= 1 || loading,
										onClick: () => goPage(page - 1),
										className: "glass inline-flex h-11 items-center gap-1 rounded-full px-3 text-sm font-medium text-fg disabled:opacity-40",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-4" }), "Prev"]
									}),
									Array.from({ length: hasNextPage ? page + 1 : page }, (_, i) => i + 1).filter((n) => n >= Math.max(1, page - 2)).map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => goPage(n),
										className: cn("flex size-11 items-center justify-center rounded-full text-sm font-medium", n === page ? "bg-fg text-bg" : "glass text-fg hover:text-fg"),
										children: n
									}, n)),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										disabled: !hasNextPage || loading,
										onClick: () => goPage(page + 1),
										className: "glass inline-flex h-11 items-center gap-1 rounded-full px-3 text-sm font-medium text-fg disabled:opacity-40",
										children: ["Next", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-4" })]
									})
								]
							}) : null
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
				className: "border-t border-border px-4 py-8 text-center text-xs text-subtle",
				children: "AniToon World · Your Ultimate Anime & Cartoon Hub"
			}),
			active ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayerModal, {
				anime: active,
				startEpisode,
				onClose: () => {
					setActive(null);
					setStartEpisode(void 0);
					refreshLocal();
				},
				onListChange: refreshLocal
			}) : null
		]
	});
}
function Home() {
	const initialItems = Route$5.useLoaderData();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AniToonApp, { initialItems });
}
//#endregion
export { Home as component };
