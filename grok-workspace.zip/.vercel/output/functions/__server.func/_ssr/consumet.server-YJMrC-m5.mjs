//#region node_modules/.nitro/vite/services/ssr/assets/consumet.server-YJMrC-m5.js
var CATEGORIES = [
	{
		id: "trending",
		label: "Trending",
		kind: "trending"
	},
	{
		id: "hindi",
		label: "Hindi Dubbed",
		kind: "hindi"
	},
	{
		id: "popular",
		label: "Popular",
		kind: "popular"
	},
	{
		id: "action",
		label: "Action",
		kind: "genre",
		genre: "Action"
	},
	{
		id: "adventure",
		label: "Adventure",
		kind: "genre",
		genre: "Adventure"
	},
	{
		id: "fantasy",
		label: "Fantasy",
		kind: "genre",
		genre: "Fantasy"
	},
	{
		id: "comedy",
		label: "Comedy",
		kind: "genre",
		genre: "Comedy"
	},
	{
		id: "movies",
		label: "Movies",
		kind: "movies"
	},
	{
		id: "cartoons",
		label: "Kids / Cartoons",
		kind: "cartoons"
	}
];
var POSTER_FALLBACK = "/poster-fallback.svg";
var MATURE_GENRE = /^(hentai|ecchi|erotica|erotic|adult)$/i;
var MATURE_TITLE = /\b(hentai|ecchi|erotica|erotic|uncensored|r-?18|rx\b|adult video|yuri hentai|yaoi hentai|tentacle)\b/i;
var MATURE_AGE = /^(R18|R\+|RX|18\+|NC-17)$/i;
var INDIAN_KIDS = /doraemon|shin-?chan|crayon shin|ninja hattori|perman|kiteretsu|pok[eé]mon|beyblade|digimon|chibi maruko|anpanman|oggy|tom and jerry|scooby|spongebob|ben 10|chhota bheem|motu patlu/;
var FAMILY_SHONEN = /naruto|one piece|dragon ball|bleach|detective conan|sailor moon|yu-?gi-?oh|cardcaptor|inazuma|precure|pre-cure|digimon|beyblade/;
var GHIBLI = /totoro|spirited away|ponyo|kiki|howl|ghibli|arrietty|mononoke|castle in the sky|whisper of the heart/;
var KIDS_CARTOON = /doraemon|shin-?chan|crayon shin|ninja hattori|perman|kiteretsu|anpanman|chibi maruko|oggy|chhota bheem|motu patlu/;
var HINDI_DUB = /demon slayer|kimetsu|jujutsu kaisen|solo leveling|naruto|boruto|one piece|dragon ball|bleach|black clover|my hero academia|boku no hero|attack on titan|shingeki|death note|tokyo revengers|chainsaw man|spy x family|kaiju no.?8|dandadan|sakamoto days|wind breaker|hunter x hunter|fairy tail|one punch|pok[eé]mon|doraemon|shin-?chan|crayon shin|ninja hattori|perman/;
function pickTitle(title, fallback = "Untitled") {
	if (!title) return fallback;
	if (typeof title === "string" && title.trim()) return title.trim();
	if (typeof title === "object") {
		const t = title;
		return t.english?.trim() || t.userPreferred?.trim() || t.romaji?.trim() || t.native?.trim() || fallback;
	}
	return fallback;
}
function stripHtml(html) {
	if (!html) return "";
	return html.replace(/<br\s*\/?>/gi, "\n").replace(/<\/?[^>]+>/g, "").replace(/&/g, "&").replace(/"/g, "\"").replace(/&#039;|'/g, "'").replace(/</g, "<").replace(/>/g, ">").replace(/&nbsp;/g, " ").replace(/\n{3,}/g, "\n\n").trim();
}
function languageBadges(title, type) {
	const t = title.toLowerCase();
	const hindi = HINDI_DUB.test(t) || INDIAN_KIDS.test(t);
	if (INDIAN_KIDS.test(t)) return [
		"Hindi",
		"English",
		"Japanese",
		"DUB"
	];
	if (hindi) return [
		"Hindi",
		"English",
		"Japanese",
		"DUB",
		"SUB"
	];
	if (FAMILY_SHONEN.test(t) || GHIBLI.test(t)) return [
		"Japanese",
		"English",
		"Hindi",
		"SUB",
		"DUB"
	];
	if (type && /movie|special/i.test(type)) return [
		"Japanese",
		"English",
		"SUB"
	];
	return [
		"Japanese",
		"English",
		"SUB"
	];
}
function hasHindiDub(title) {
	return HINDI_DUB.test(title.toLowerCase()) || INDIAN_KIDS.test(title.toLowerCase());
}
function isMatureTitle(card) {
	if (card.ageRating && MATURE_AGE.test(card.ageRating)) return true;
	if (card.genres?.some((g) => MATURE_GENRE.test(g))) return true;
	if (MATURE_TITLE.test(card.title)) return true;
	if (card.description && MATURE_TITLE.test(card.description)) return true;
	return false;
}
function isKidsCartoon(card) {
	return KIDS_CARTOON.test(card.title);
}
function buildEmbedServers(anilistId, malId, episode, title = "") {
	const servers = [];
	const id = String(anilistId).replace(/^(mal|kitsu|gogo)-/, "");
	const ep = Math.max(1, episode);
	const hindi = hasHindiDub(title);
	if (hindi && /^\d+$/.test(id)) servers.push({
		id: "videasy-hindi",
		name: "Hindi Dub",
		url: `https://player.videasy.to/anime/${id}/${ep}?dub=hindi&color=e50914`
	});
	if (/^\d+$/.test(id)) {
		servers.push({
			id: "videasy-sub",
			name: "Japanese SUB",
			url: `https://player.videasy.to/anime/${id}/${ep}?color=e50914`
		});
		servers.push({
			id: "videasy-dub",
			name: "English Dub",
			url: `https://player.videasy.to/anime/${id}/${ep}?dub=true&color=e50914`
		});
	}
	if (malId) {
		if (hindi) servers.push({
			id: "vidstream-hindi",
			name: "Vidstream · Hindi",
			url: `https://vidsrc.pm/embed/anime/${malId}/${ep}/hindi`
		});
		servers.push({
			id: "vidstream",
			name: "Vidstream",
			url: `https://vidsrc.pm/embed/anime/${malId}/${ep}`
		});
		servers.push({
			id: "vidstream-dub",
			name: "Vidstream · DUB",
			url: `https://vidsrc.pm/embed/anime/${malId}/${ep}/dub`
		});
		servers.push({
			id: "streamwish",
			name: "StreamWish",
			url: `https://vidsrc.sh/embed/anime?mal=${malId}&ep=${ep}`
		});
		servers.push({
			id: "vidsrc-tw",
			name: "Server 4",
			url: `https://vidsrc.tw/embed/anime/${malId}/${ep}`
		});
		servers.push({
			id: "2embed",
			name: "2Embed",
			url: `https://www.2embed.cc/embed/anime/${malId}/${ep}`
		});
	}
	return servers;
}
var CONTINUE_KEY = "anitoon:continue";
var LIST_KEY = "anitoon:watchlist";
var HISTORY_KEY = "anitoon:history";
function readJson(key, fallback) {
	if (typeof window === "undefined") return fallback;
	try {
		const raw = localStorage.getItem(key);
		if (!raw) return fallback;
		return JSON.parse(raw);
	} catch {
		return fallback;
	}
}
function migrateKeys() {
	if (typeof window === "undefined") return;
	const pairs = [["kage:continue", CONTINUE_KEY], ["kage:mylist", LIST_KEY]];
	for (const [from, to] of pairs) if (!localStorage.getItem(to) && localStorage.getItem(from)) localStorage.setItem(to, localStorage.getItem(from));
}
function getContinueWatching() {
	migrateKeys();
	return readJson(CONTINUE_KEY, []).sort((a, b) => b.updatedAt - a.updatedAt);
}
function saveContinueWatching(entry) {
	const next = getContinueWatching().filter((item) => item.id !== entry.id);
	next.unshift(entry);
	localStorage.setItem(CONTINUE_KEY, JSON.stringify(next.slice(0, 18)));
}
function getMyList() {
	migrateKeys();
	return readJson(LIST_KEY, []);
}
function toggleMyList(entry) {
	const list = getMyList();
	const next = list.some((item) => item.id === entry.id) ? list.filter((item) => item.id !== entry.id) : [{
		...entry,
		episode: 1,
		updatedAt: Date.now()
	}, ...list].slice(0, 60);
	localStorage.setItem(LIST_KEY, JSON.stringify(next));
	return next;
}
function isInMyList(id) {
	return getMyList().some((item) => item.id === id);
}
function getWatchHistory() {
	return readJson(HISTORY_KEY, []).sort((a, b) => b.updatedAt - a.updatedAt);
}
function pushWatchHistory(entry) {
	const next = getWatchHistory().filter((item) => !(item.id === entry.id && item.episode === entry.episode));
	next.unshift(entry);
	localStorage.setItem(HISTORY_KEY, JSON.stringify(next.slice(0, 40)));
	saveContinueWatching(entry);
}
function clearWatchHistory() {
	localStorage.removeItem(HISTORY_KEY);
	localStorage.removeItem(CONTINUE_KEY);
}
async function api(path) {
	const res = await fetch(path, { headers: { accept: "application/json" } });
	if (!res.ok) {
		const text = await res.text().catch(() => "");
		throw new Error(text || `Request failed (${res.status})`);
	}
	return await res.json();
}
function fetchCatalog(kind, genre, page = 1) {
	const params = new URLSearchParams({
		kind,
		page: String(page)
	});
	if (genre) params.set("genre", genre);
	return api(`/api/catalog?${params}`);
}
function fetchSearch(query, page = 1) {
	return api(`/api/search?${new URLSearchParams({
		q: query,
		page: String(page)
	})}`);
}
function fetchInfo(id, title) {
	const params = new URLSearchParams({ id });
	if (title) params.set("title", title);
	return api(`/api/info?${params}`);
}
function fetchStream(opts) {
	const params = new URLSearchParams({
		anilistId: opts.anilistId,
		episode: String(opts.episode)
	});
	if (opts.malId) params.set("malId", String(opts.malId));
	if (opts.episodeId) params.set("episodeId", opts.episodeId);
	if (opts.title) params.set("title", opts.title);
	return api(`/api/stream?${params}`);
}
var CONSUMET_BASES = [
	"https://consumet-ten.vercel.app",
	"https://consumet-api-clone.vercel.app",
	"https://api.consumet.org"
];
var ANILIST = "https://graphql.anilist.co";
var KITSU = "https://kitsu.io/api/edge/anime";
var JIKAN = "https://api.jikan.moe/v4/anime";
var cache = /* @__PURE__ */ new Map();
var TTL_MS = 48e4;
var CARTOON_QUERIES = [
	"Doraemon",
	"Crayon Shin-chan",
	"Ninja Hattori",
	"Perman",
	"Pokémon",
	"Tom and Jerry",
	"Oggy"
];
var HINDI_QUERIES = [
	"Demon Slayer",
	"Jujutsu Kaisen",
	"Solo Leveling",
	"Naruto",
	"One Piece",
	"Dragon Ball Super",
	"Black Clover",
	"My Hero Academia",
	"Attack on Titan",
	"Death Note"
];
[
	{
		id: "2471",
		malId: 2471,
		title: "Doraemon (1979)",
		image: "",
		type: "TV"
	},
	{
		id: "527",
		malId: 527,
		title: "Pokémon",
		image: "",
		type: "TV"
	},
	{
		id: "966",
		malId: 966,
		title: "Crayon Shin-chan",
		image: "",
		type: "TV"
	},
	{
		id: "20",
		malId: 20,
		title: "Naruto",
		image: "",
		type: "TV"
	},
	{
		id: "21",
		malId: 21,
		title: "One Piece",
		image: "",
		type: "TV"
	},
	{
		id: "223",
		malId: 223,
		title: "Dragon Ball",
		image: "",
		type: "TV"
	},
	{
		id: "523",
		malId: 523,
		title: "My Neighbor Totoro",
		image: "",
		type: "MOVIE"
	},
	{
		id: "164",
		malId: 164,
		title: "Spirited Away",
		image: "",
		type: "MOVIE"
	},
	{
		id: "235",
		malId: 235,
		title: "Detective Conan",
		image: "",
		type: "TV"
	}
].map((c) => ({
	...c,
	languages: languageBadges(c.title, c.type)
}));
function fromCache(key) {
	const hit = cache.get(key);
	if (!hit) return null;
	if (Date.now() - hit.at > TTL_MS) {
		cache.delete(key);
		return null;
	}
	return hit.data;
}
function toCache(key, data) {
	cache.set(key, {
		at: Date.now(),
		data
	});
	return data;
}
async function fetchJson(url, ms = 9e3) {
	try {
		const res = await fetch(url, {
			headers: { accept: "application/json" },
			signal: AbortSignal.timeout(ms)
		});
		const ct = res.headers.get("content-type") ?? "";
		if (!res.ok || !ct.includes("json")) return null;
		const data = await res.json();
		if (data && typeof data === "object" && "message" in data && !("results" in data) && !("episodes" in data) && !("data" in data) && !("id" in data && "title" in data)) return null;
		return data;
	} catch {
		return null;
	}
}
async function consumetGet(path, ms = 7e3) {
	for (const base of CONSUMET_BASES) {
		const data = await fetchJson(`${base}${path}`, ms);
		if (data) return data;
	}
	return null;
}
var MEDIA_FIELDS = `
  id
  idMal
  title { romaji english native userPreferred }
  description(asHtml: false)
  coverImage { extraLarge large color }
  bannerImage
  averageScore
  status
  format
  seasonYear
  episodes
  genres
  isAdult
  trailer { id site }
`;
async function anilistQuery(query, variables = {}) {
	try {
		const res = await fetch(ANILIST, {
			method: "POST",
			headers: {
				"content-type": "application/json",
				accept: "application/json"
			},
			body: JSON.stringify({
				query,
				variables
			}),
			signal: AbortSignal.timeout(12e3)
		});
		if (!res.ok) return null;
		return (await res.json()).data ?? null;
	} catch {
		return null;
	}
}
function decorate(card) {
	return {
		...card,
		languages: card.languages?.length ? card.languages : languageBadges(card.title, card.type)
	};
}
function fromAnilist(m) {
	if (m.isAdult) return null;
	const card = {
		id: String(m.id),
		malId: m.idMal ?? void 0,
		title: pickTitle(m.title),
		image: m.coverImage?.extraLarge || m.coverImage?.large || "",
		cover: m.bannerImage || void 0,
		rating: m.averageScore ?? void 0,
		status: m.status ?? void 0,
		type: m.format ?? void 0,
		releaseDate: m.seasonYear ? String(m.seasonYear) : void 0,
		genres: m.genres ?? void 0,
		description: stripHtml(m.description),
		totalEpisodes: m.episodes ?? void 0,
		color: m.coverImage?.color ?? void 0
	};
	if (isMatureTitle(card)) return null;
	return decorate(card);
}
function fromConsumet(item) {
	if (item.id == null) return null;
	const card = {
		id: String(item.id),
		malId: item.malId,
		gogoId: typeof item.id === "string" && /[a-z]/i.test(item.id) ? String(item.id) : void 0,
		title: pickTitle(item.title),
		image: item.image || "",
		cover: item.cover,
		rating: item.rating,
		status: item.status,
		type: item.type,
		releaseDate: item.releaseDate != null ? String(item.releaseDate) : void 0,
		genres: item.genres,
		description: stripHtml(item.description),
		totalEpisodes: item.totalEpisodes,
		color: item.color
	};
	if (isMatureTitle(card)) return null;
	return decorate(card);
}
function resultsFromConsumet(data) {
	if (!data || typeof data !== "object") return [];
	const results = data.results;
	if (!Array.isArray(results)) return [];
	return results.map(fromConsumet).filter((x) => Boolean(x));
}
function fromKitsu(item) {
	const a = item.attributes;
	if (!a) return null;
	const title = a.titles?.en || a.canonicalTitle || a.titles?.en_jp || "Untitled";
	const card = {
		id: `kitsu-${item.id}`,
		title,
		image: a.posterImage?.large || a.posterImage?.original || "",
		cover: a.coverImage?.original || a.coverImage?.large,
		rating: a.averageRating ? Math.round(Number(a.averageRating)) : void 0,
		status: a.status,
		type: a.subtype?.toUpperCase(),
		releaseDate: a.startDate ? a.startDate.slice(0, 4) : void 0,
		description: stripHtml(a.synopsis),
		totalEpisodes: a.episodeCount,
		ageRating: a.ageRating
	};
	if (isMatureTitle(card)) return null;
	return decorate(card);
}
function fromJikan(item) {
	if (!item.mal_id) return null;
	const card = {
		id: `mal-${item.mal_id}`,
		malId: item.mal_id,
		title: item.title_english || item.title || "Untitled",
		image: item.images?.jpg?.large_image_url || item.images?.jpg?.image_url || "",
		rating: item.score ? Math.round(item.score * 10) : void 0,
		status: item.status,
		type: item.type,
		releaseDate: item.year ? String(item.year) : void 0,
		genres: item.genres?.map((g) => g.name || "").filter(Boolean),
		description: stripHtml(item.synopsis),
		totalEpisodes: item.episodes,
		ageRating: item.rating
	};
	if (isMatureTitle(card)) return null;
	return decorate(card);
}
function mergeCards(lists) {
	const seen = /* @__PURE__ */ new Set();
	const out = [];
	const remember = (card) => {
		const keys = [
			card.id,
			card.malId ? `mal-${card.malId}` : "",
			card.title.toLowerCase().replace(/[^a-z0-9]+/g, " ").trim()
		].filter(Boolean);
		if (keys.some((k) => seen.has(k))) return;
		for (const k of keys) seen.add(k);
		out.push(card);
	};
	for (const list of lists) for (const card of list) remember(card);
	return out;
}
async function anilistPage(opts) {
	const variables = {
		page: opts.page ?? 1,
		perPage: opts.perPage ?? 24,
		sort: [opts.sort ?? "TRENDING_DESC"]
	};
	const defs = [
		"$page: Int",
		"$perPage: Int",
		"$sort: [MediaSort]"
	];
	const args = [
		"type: ANIME",
		"sort: $sort",
		"isAdult: false"
	];
	if (opts.genre) {
		defs.push("$genre: String");
		args.push("genre: $genre");
		variables.genre = opts.genre;
	}
	if (opts.format) {
		defs.push("$format: MediaFormat");
		args.push("format: $format");
		variables.format = opts.format;
	}
	if (opts.search) {
		defs.push("$search: String");
		args.push("search: $search");
		variables.search = opts.search;
	}
	if (opts.tag) {
		defs.push("$tag: String");
		args.push("tag: $tag");
		variables.tag = opts.tag;
	}
	const data = await anilistQuery(`query (${defs.join(", ")}) {
      Page(page: $page, perPage: $perPage) {
        pageInfo { hasNextPage }
        media(${args.join(", ")}) { ${MEDIA_FIELDS} }
      }
    }`, variables);
	return {
		results: (data?.Page?.media ?? []).map(fromAnilist).filter((x) => Boolean(x)),
		hasNextPage: Boolean(data?.Page?.pageInfo?.hasNextPage)
	};
}
async function kitsuSearch(query, page = 1) {
	const offset = (page - 1) * 20;
	return ((await fetchJson(`${KITSU}?filter%5Btext%5D=${encodeURIComponent(query)}&page%5Blimit%5D=20&page%5Boffset%5D=${offset}`, 8e3))?.data ?? []).map(fromKitsu).filter((x) => Boolean(x));
}
async function jikanSearch(query, page = 1) {
	return ((await fetchJson(`${JIKAN}?q=${encodeURIComponent(query)}&sfw=true&page=${page}&limit=25`, 8e3))?.data ?? []).map(fromJikan).filter((x) => Boolean(x));
}
async function resolveAnilistId(card) {
	if (/^\d+$/.test(card.id)) return card;
	if (card.malId) {
		const data = await anilistQuery(`query ($id: Int) { Media(idMal: $id, type: ANIME) { ${MEDIA_FIELDS} } }`, { id: card.malId });
		const mapped = data?.Media ? fromAnilist(data.Media) : null;
		if (mapped) return {
			...card,
			...mapped,
			languages: card.languages
		};
	}
	const mapped = (await anilistPage({
		search: card.title,
		sort: "SEARCH_MATCH",
		perPage: 5
	})).results[0];
	if (mapped) return {
		...card,
		id: mapped.id,
		malId: mapped.malId ?? card.malId,
		image: card.image || mapped.image
	};
	return card;
}
function withoutKidsCartoons(cards) {
	return cards.filter((c) => !isKidsCartoon(c));
}
async function loadCatalog(opts) {
	const page = opts.page ?? 1;
	const key = `cat:${opts.kind}:${opts.genre ?? ""}:${page}`;
	const cached = fromCache(key);
	if (cached) return cached;
	if (opts.kind === "cartoons" || opts.kind === "family") {
		if (page === 1) return toCache(key, {
			results: mergeCards((await Promise.all(CARTOON_QUERIES.map((q) => anilistPage({
				search: q,
				sort: "SEARCH_MATCH",
				perPage: 8
			})))).map((p) => p.results)),
			hasNextPage: true
		});
		return toCache(key, await anilistPage({
			tag: "Kids",
			sort: "POPULARITY_DESC",
			page,
			perPage: 24
		}));
	}
	if (opts.kind === "hindi") {
		if (page === 1) {
			const merged = mergeCards((await Promise.all(HINDI_QUERIES.map((q) => anilistPage({
				search: q,
				sort: "SEARCH_MATCH",
				perPage: 6
			})))).map((p) => p.results));
			const results = merged.filter((c) => hasHindiDub(c.title));
			return toCache(key, {
				results: results.length ? results : merged,
				hasNextPage: true
			});
		}
		const more = await anilistPage({
			sort: "POPULARITY_DESC",
			page,
			perPage: 24
		});
		return toCache(key, {
			results: more.results.filter((c) => hasHindiDub(c.title)),
			hasNextPage: more.hasNextPage
		});
	}
	if (opts.kind === "topic" && opts.genre) return toCache(key, await loadSearch(opts.genre, page, false));
	if (opts.kind === "movies") {
		const movies = await anilistPage({
			sort: "POPULARITY_DESC",
			format: "MOVIE",
			page,
			perPage: 24
		});
		return toCache(key, {
			results: withoutKidsCartoons(movies.results),
			hasNextPage: movies.hasNextPage
		});
	}
	if (opts.kind === "genre" && opts.genre && opts.genre !== "Kids") {
		const payload = await anilistPage({
			sort: "POPULARITY_DESC",
			genre: opts.genre,
			page,
			perPage: 24
		});
		return toCache(key, {
			results: withoutKidsCartoons(payload.results),
			hasNextPage: payload.hasNextPage
		});
	}
	if (opts.kind === "popular") {
		const payload = await anilistPage({
			sort: "POPULARITY_DESC",
			page,
			perPage: 24
		});
		return toCache(key, {
			results: withoutKidsCartoons(payload.results),
			hasNextPage: payload.hasNextPage
		});
	}
	const payload = await anilistPage({
		sort: "TRENDING_DESC",
		page,
		perPage: 24
	});
	return toCache(key, {
		results: withoutKidsCartoons(payload.results),
		hasNextPage: payload.hasNextPage
	});
}
async function loadSearch(query, page = 1, familyBias = false) {
	const q = query.trim();
	if (q.length < 2) return {
		results: [],
		hasNextPage: false
	};
	const key = `search-v2:${q}:${page}:${familyBias ? "f" : "a"}`;
	const cached = fromCache(key);
	if (cached?.results.length) return cached;
	const popularCartoon = /doraemon|pok[eé]mon|shin-?chan|hattori|naruto/i.test(q);
	const anilistMain = await anilistPage({
		search: q,
		sort: "SEARCH_MATCH",
		page,
		perPage: 25
	});
	const extras = page === 1 ? await Promise.all([
		kitsuSearch(q, 1),
		jikanSearch(q, 1),
		consumetGet(`/anime/gogoanime/${encodeURIComponent(q)}?page=1`, 4e3).then(resultsFromConsumet),
		popularCartoon ? anilistPage({
			search: `${q} movie`,
			sort: "SEARCH_MATCH",
			perPage: 25
		}).then((r) => r.results) : Promise.resolve([]),
		popularCartoon ? anilistPage({
			search: `${q} special`,
			sort: "SEARCH_MATCH",
			perPage: 20
		}).then((r) => r.results) : Promise.resolve([])
	]) : [
		[],
		[],
		[],
		[],
		[]
	];
	const merged = mergeCards([
		anilistMain.results,
		extras[3] ?? [],
		extras[4] ?? [],
		extras[0] ?? [],
		extras[1] ?? [],
		extras[2] ?? []
	]);
	const resolvedExtras = await Promise.all(merged.filter((card) => !/^\d+$/.test(card.id)).slice(0, 8).map(async (card) => {
		try {
			return await resolveAnilistId(card);
		} catch {
			return card;
		}
	}));
	let results = mergeCards([merged.filter((card) => /^\d+$/.test(card.id)), resolvedExtras]);
	if (familyBias) results = results.filter((c) => !isMatureTitle(c));
	const payload = {
		results,
		hasNextPage: anilistMain.hasNextPage || results.length >= 20
	};
	if (results.length) toCache(key, payload);
	return payload;
}
function buildEpisodes(count, animeId) {
	const n = Math.min(Math.max(count || 12, 1), 2500);
	return Array.from({ length: n }, (_, i) => ({
		id: `${animeId}-episode-${i + 1}`,
		number: i + 1,
		title: `Episode ${i + 1}`
	}));
}
async function loadInfo(id, titleHint) {
	const key = `info:${id}:${titleHint ?? ""}`;
	const cached = fromCache(key);
	if (cached) return cached;
	let media = null;
	const numericId = Number(id);
	const malMatch = /^mal-(\d+)$/.exec(id);
	if (Number.isFinite(numericId) && /^\d+$/.test(id)) media = (await anilistQuery(`query ($id: Int) { Media(id: $id, type: ANIME) { ${MEDIA_FIELDS} } }`, { id: numericId }))?.Media ?? null;
	else if (malMatch) media = (await anilistQuery(`query ($id: Int) { Media(idMal: $id, type: ANIME) { ${MEDIA_FIELDS} } }`, { id: Number(malMatch[1]) }))?.Media ?? null;
	else if (titleHint) {
		const found = await anilistPage({
			search: titleHint,
			sort: "SEARCH_MATCH",
			perPage: 1
		});
		if (found.results[0]) media = (await anilistQuery(`query ($id: Int) { Media(id: $id, type: ANIME) { ${MEDIA_FIELDS} } }`, { id: Number(found.results[0].id) }))?.Media ?? null;
	}
	if (!media) return null;
	const card = fromAnilist(media);
	if (!card) return null;
	const episodes = buildEpisodes(card.totalEpisodes ?? 12, card.id);
	return toCache(key, {
		...card,
		episodes,
		trailer: media.trailer?.id ? {
			id: media.trailer.id,
			site: media.trailer.site ?? "youtube"
		} : null
	});
}
async function loadStream(opts) {
	const servers = [];
	const ep = opts.episode;
	const anilistId = opts.anilistId.replace(/^(mal|kitsu|gogo)-/, "");
	const mal = opts.malId;
	if (opts.episodeId && /[a-z]/i.test(opts.episodeId) && !/^\d+-episode-\d+$/.test(opts.episodeId)) {
		const watch = await consumetGet(`/anime/gogoanime/watch/${encodeURIComponent(opts.episodeId)}`, 4e3);
		if (watch?.sources?.length) for (const src of watch.sources) {
			if (!src.url) continue;
			servers.push({
				id: `gogo-${src.quality ?? servers.length}`,
				name: `Gogo ${src.quality ?? "Auto"}`,
				url: src.url,
				download: watch.download
			});
		}
		const list = await consumetGet(`/anime/gogoanime/servers/${encodeURIComponent(opts.episodeId)}`, 4e3);
		if (Array.isArray(list)) for (const s of list) {
			if (!s.url) continue;
			servers.push({
				id: `gogo-iframe-${s.name ?? servers.length}`,
				name: s.name || "Gogo embed",
				url: s.url
			});
		}
	}
	if (/^\d+$/.test(anilistId)) {
		if (opts.title && hasHindiDub(opts.title)) servers.push({
			id: "videasy-hindi",
			name: "Hindi Dub",
			url: `https://player.videasy.to/anime/${anilistId}/${ep}?dub=hindi&color=e50914`
		});
		servers.push({
			id: "videasy-sub",
			name: "Japanese SUB",
			url: `https://player.videasy.to/anime/${anilistId}/${ep}?color=e50914`
		});
		servers.push({
			id: "videasy-dub",
			name: "English Dub",
			url: `https://player.videasy.to/anime/${anilistId}/${ep}?dub=true&color=e50914`
		});
	}
	if (mal) {
		servers.push({
			id: "vidstream",
			name: "Vidstream",
			url: `https://vidsrc.pm/embed/anime/${mal}/${ep}`
		});
		if (opts.title && hasHindiDub(opts.title)) servers.push({
			id: "vidstream-hindi",
			name: "Vidstream · Hindi",
			url: `https://vidsrc.pm/embed/anime/${mal}/${ep}/hindi`
		});
		servers.push({
			id: "vidstream-dub",
			name: "Vidstream · DUB",
			url: `https://vidsrc.pm/embed/anime/${mal}/${ep}/dub`
		});
		servers.push({
			id: "streamwish",
			name: "StreamWish",
			url: `https://vidsrc.sh/embed/anime?mal=${mal}&ep=${ep}`
		});
		servers.push({
			id: "vidsrc-tw",
			name: "Server 4",
			url: `https://vidsrc.tw/embed/anime/${mal}/${ep}`
		});
		servers.push({
			id: "2embed",
			name: "2Embed",
			url: `https://www.2embed.cc/embed/anime/${mal}/${ep}`
		});
	}
	const seen = /* @__PURE__ */ new Set();
	return {
		servers: servers.filter((s) => {
			if (seen.has(s.url)) return false;
			seen.add(s.url);
			return true;
		}),
		trailer: null
	};
}
//#endregion
export { pushWatchHistory as _, fetchCatalog as a, fetchStream as c, getWatchHistory as d, isInMyList as f, loadStream as g, loadSearch as h, clearWatchHistory as i, getContinueWatching as l, loadInfo as m, POSTER_FALLBACK as n, fetchInfo as o, loadCatalog as p, buildEmbedServers as r, fetchSearch as s, CATEGORIES as t, getMyList as u, toggleMyList as v };
